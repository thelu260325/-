通信网络作业：PPT 与讲稿复核版（2026年11月11日）

只需使用本包中的四个文件：
1. Communication_Networks_Presentation.pptx：可编辑 PPT，共15页，备注中有逐页英文讲稿。
2. Communication_Networks_Presentation.pdf：从该 PPT 导出的阅读备用版。
3. Presentation_Script_and_QA.docx：可编辑英文讲稿、时间分配、发音提示及15条答辩问答。
4. Presentation_Script_and_QA.pdf：从该 Word 导出的6页打印版。

展示分工：
孙建庚 202612491511：第1—5页；讲稿 PDF 第2页。
钱图   202612491508：第6—10页；讲稿 PDF 第3页。
陆子芃 202612491522：第11—15页；讲稿 PDF 第4页。
各安排3分20秒，合计10分钟。正式朗读正文共1072词。
讲稿 PDF 第1页是时间表和发音提示，第5—6页是答辩准备内容，不计入正文朗读。

使用前请三人连贯计时排练一次，保留指图、换页和交接的时间；10分钟是分配目标，并非已实测的录音时长。
在上课使用的电脑上打开 PPT 检查字体与投影效果，另带 PDF 备用。
