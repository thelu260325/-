"""Host-side format reference only; no UART, STM32 firmware or flash driver.

Modbus RTU: address 1, read-only function 03, eight holding registers.
Records: 30-byte little-endian payload + 2-byte little-endian Modbus CRC.
"""
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
import math
import struct


def crc16_modbus(data: bytes) -> int:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0xA001 if crc & 1 else 0)
    return crc


def with_crc(payload: bytes) -> bytes:
    return payload + struct.pack('<H', crc16_modbus(payload))


def rounded(value: float, scale: int = 1) -> int:
    return int((Decimal(str(value)) * scale).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


@dataclass(frozen=True)
class Snapshot:
    temperature_c: float | None
    humidity_rh: float | None
    pressure_pa: int | None
    brightness_index: float | None
    flags: int = 0
    fan_percent: int = 0
    heat_on: bool = False
    lamp_percent: int = 0

    def validate(self):
        for name, value, low, high in [
            ('temperature_c', self.temperature_c, -55, 125),
            ('humidity_rh', self.humidity_rh, 0, 100),
            ('pressure_pa', self.pressure_pa, 30000, 110000),
            ('brightness_index', self.brightness_index, 0, 100),
        ]:
            if value is not None and (not math.isfinite(value) or not low <= value <= high):
                raise ValueError(name)
        if not 0 <= self.flags <= 0x3F:
            raise ValueError('flags: bits 6 and 7 are reserved')
        for value in [self.fan_percent, self.lamp_percent]:
            if type(value) is not int or not 0 <= value <= 100:
                raise ValueError('actuator percent')
        if type(self.heat_on) is not bool:
            raise ValueError('heat_on')

    @property
    def effective_flags(self) -> int:
        flags = self.flags
        for bit, value in [(1, self.temperature_c), (2, self.brightness_index),
                           (3, self.humidity_rh), (5, self.pressure_pa)]:
            if value is None:
                flags |= 1 << bit
        return flags

    def registers(self) -> tuple[int, ...]:
        self.validate()
        return (
            0x8000 if self.temperature_c is None else rounded(self.temperature_c, 10) & 0xFFFF,
            0xFFFF if self.humidity_rh is None else rounded(self.humidity_rh, 10),
            0xFFFF if self.pressure_pa is None else rounded(Decimal(self.pressure_pa) / 10),
            0xFFFF if self.brightness_index is None else rounded(self.brightness_index),
            self.effective_flags,
            self.fan_percent,
            int(self.heat_on),
            self.lamp_percent,
        )


def read_request(start: int = 0, count: int = 8) -> bytes:
    return with_crc(struct.pack('>BBHH', 1, 3, start, count))


def respond_rtu(request: bytes, snapshot: Snapshot) -> bytes | None:
    """A complete-frame host model. None means no response, not a timeout model.

    Complete requests must have length 8; function 03 supports valid subsets
    of the 8-register map. No writable register or write function exists.
    """
    if len(request) != 8 or request[0] != 1:
        return None
    if crc16_modbus(request[:-2]) != struct.unpack('<H', request[-2:])[0]:
        return None
    address, function, start, count = struct.unpack('>BBHH', request[:-2])
    if function != 3:
        return with_crc(bytes([address, function | 0x80, 1]))
    if not 1 <= count <= 125:
        return with_crc(bytes([address, 0x83, 3]))
    if start >= 8 or start + count > 8:
        return with_crc(bytes([address, 0x83, 2]))
    registers = snapshot.registers()[start:start + count]
    return with_crc(bytes([address, 3, 2 * count]) + struct.pack('>' + 'H' * count, *registers))


RECORD_MAGIC = 0xA55A
RECORD_VERSION = 1
RECORD_SIZE = 32
PREFIX = struct.Struct('<HBBIIhHIHBBB5s')
assert PREFIX.size == 30


@dataclass(frozen=True)
class LogRecord:
    unix_seconds: int
    sequence: int
    snapshot: Snapshot


def encode_record(record: LogRecord) -> bytes:
    s = record.snapshot
    s.validate()
    for value in [record.unix_seconds, record.sequence]:
        if type(value) is not int or not 0 <= value <= 0xFFFFFFFF:
            raise ValueError('32-bit timestamp or sequence')
    payload = PREFIX.pack(
        RECORD_MAGIC, RECORD_VERSION, s.effective_flags,
        record.unix_seconds, record.sequence,
        -32768 if s.temperature_c is None else rounded(s.temperature_c, 10),
        0xFFFF if s.humidity_rh is None else rounded(s.humidity_rh, 10),
        0xFFFFFFFF if s.pressure_pa is None else int(s.pressure_pa),
        0xFFFF if s.brightness_index is None else rounded(s.brightness_index, 10),
        s.fan_percent, int(s.heat_on), s.lamp_percent, bytes(5),
    )
    return with_crc(payload)


def decode_record(data: bytes) -> LogRecord:
    if len(data) != RECORD_SIZE:
        raise ValueError('record length')
    if crc16_modbus(data[:-2]) != struct.unpack('<H', data[-2:])[0]:
        raise ValueError('record CRC')
    (magic, version, flags, timestamp, sequence, temperature, humidity,
     pressure, brightness, fan, heat, lamp, reserved) = PREFIX.unpack(data[:-2])
    if magic != RECORD_MAGIC or version != RECORD_VERSION or reserved != bytes(5):
        raise ValueError('record format')
    if heat not in (0, 1):
        raise ValueError('heat')
    s = Snapshot(
        None if temperature == -32768 else temperature / 10,
        None if humidity == 0xFFFF else humidity / 10,
        None if pressure == 0xFFFFFFFF else pressure,
        None if brightness == 0xFFFF else brightness / 10,
        flags, fan, bool(heat), lamp,
    )
    s.validate()
    return LogRecord(timestamp, sequence, s)


if __name__ == '__main__':
    s = Snapshot(23.4, 56.7, 101325, 27, fan_percent=40, lamp_percent=60)
    print('request:', read_request().hex(' '))
    print('response:', respond_rtu(read_request(), s).hex(' '))
    data = encode_record(LogRecord(1793145600, 1, s))
    print('32-byte record:', data.hex(' '))
    print('decoded:', decode_record(data))
