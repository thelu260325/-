import struct
import unittest
from reference_interfaces import (
    Snapshot, LogRecord, crc16_modbus, with_crc, read_request,
    respond_rtu, encode_record, decode_record,
)


class InterfaceTests(unittest.TestCase):
    def setUp(self):
        self.s = Snapshot(23.4, 56.7, 101325, 27, fan_percent=40, lamp_percent=60)

    def test_crc_standard_check_vector(self):
        self.assertEqual(crc16_modbus(b'123456789'), 0x4B37)

    def test_crc_known_modbus_request(self):
        self.assertEqual(with_crc(bytes.fromhex('01030000000a')).hex(), '01030000000ac5cd')

    def test_read_eight_registers_and_response_length(self):
        response = respond_rtu(read_request(), self.s)
        self.assertEqual(len(response), 21)
        self.assertEqual(response[:3], bytes([1, 3, 16]))
        self.assertEqual(struct.unpack('>8H', response[3:-2]), (234,567,10133,27,0,40,0,60))
        self.assertEqual(crc16_modbus(response[:-2]), struct.unpack('<H', response[-2:])[0])

    def test_negative_temperature_twos_complement(self):
        s = Snapshot(-12.3, 50, 100000, 0)
        self.assertEqual(s.registers()[0], 0xFF85)

    def test_pressure_half_rounds_up(self):
        self.assertEqual(self.s.registers()[2], 10133)

    def test_read_subrange(self):
        response = respond_rtu(read_request(5, 3), self.s)
        self.assertEqual(response[2], 6)
        self.assertEqual(struct.unpack('>3H', response[3:-2]), (40,0,60))

    def test_bad_crc_silently_ignored(self):
        r = bytearray(read_request()); r[4] ^= 1
        self.assertIsNone(respond_rtu(bytes(r), self.s))

    def test_broadcast_read_silently_ignored(self):
        r = with_crc(bytes.fromhex('000300000008'))
        self.assertIsNone(respond_rtu(r, self.s))

    def test_wrong_length_silently_ignored(self):
        self.assertIsNone(respond_rtu(read_request()[:-1], self.s))

    def test_unsupported_function_exception_01(self):
        r = with_crc(bytes.fromhex('010600000001'))
        self.assertEqual(respond_rtu(r, self.s)[:3], bytes.fromhex('018601'))

    def test_bad_address_exception_02(self):
        self.assertEqual(respond_rtu(read_request(7,2), self.s)[:3], bytes.fromhex('018302'))

    def test_zero_count_exception_03(self):
        self.assertEqual(respond_rtu(read_request(0,0), self.s)[:3], bytes.fromhex('018303'))

    def test_excess_count_exception_03(self):
        self.assertEqual(respond_rtu(read_request(0,126), self.s)[:3], bytes.fromhex('018303'))

    def test_nine_registers_exceed_map_exception_02(self):
        self.assertEqual(respond_rtu(read_request(0,9), self.s)[:3], bytes.fromhex('018302'))

    def test_missing_fields_have_sentinels_and_flags(self):
        s = Snapshot(None,None,None,None,flags=1 | 1<<4)
        self.assertEqual(s.registers(), (0x8000,0xFFFF,0xFFFF,0xFFFF,0x3F,0,0,0))

    def test_record_size_and_roundtrip(self):
        record = LogRecord(1793145600,12345,self.s)
        data = encode_record(record)
        self.assertEqual(len(data),32)
        self.assertEqual(decode_record(data),record)

    def test_negative_temperature_record(self):
        record = LogRecord(1,1,Snapshot(-12.3,0,30000,100,fan_percent=100,heat_on=True))
        self.assertEqual(decode_record(encode_record(record)),record)

    def test_missing_record_fields_roundtrip(self):
        record = LogRecord(0,0,Snapshot(None,None,None,None))
        restored = decode_record(encode_record(record))
        self.assertIsNone(restored.snapshot.temperature_c)
        self.assertIsNone(restored.snapshot.humidity_rh)
        self.assertIsNone(restored.snapshot.pressure_pa)
        self.assertIsNone(restored.snapshot.brightness_index)
        self.assertEqual(restored.snapshot.flags,0x2E)

    def test_record_corruption_rejected(self):
        data=bytearray(encode_record(LogRecord(1,1,self.s))); data[14] ^= 1
        with self.assertRaisesRegex(ValueError,'CRC'):
            decode_record(bytes(data))

    def test_record_short_rejected(self):
        with self.assertRaisesRegex(ValueError,'length'):
            decode_record(bytes(31))

    def test_record_wrong_version_even_with_valid_crc(self):
        data=bytearray(encode_record(LogRecord(1,1,self.s))); data[2]=2
        with self.assertRaisesRegex(ValueError,'format'):
            decode_record(with_crc(bytes(data[:-2])))

    def test_record_nonzero_reserved_rejected(self):
        data=bytearray(encode_record(LogRecord(1,1,self.s))); data[29]=1
        with self.assertRaisesRegex(ValueError,'format'):
            decode_record(with_crc(bytes(data[:-2])))

    def test_timestamp_and_sequence_limits(self):
        r=LogRecord(0xFFFFFFFF,0xFFFFFFFF,self.s)
        self.assertEqual(decode_record(encode_record(r)),r)
        with self.assertRaises(ValueError): encode_record(LogRecord(-1,1,self.s))
        with self.assertRaises(ValueError): encode_record(LogRecord(1,1<<32,self.s))

    def test_percent_out_of_range_rejected(self):
        with self.assertRaises(ValueError): Snapshot(20,50,100000,20,fan_percent=101).registers()

    def test_nan_sensor_rejected(self):
        with self.assertRaises(ValueError): Snapshot(float('nan'),50,100000,20).registers()


if __name__ == '__main__':
    unittest.main(verbosity=2)
