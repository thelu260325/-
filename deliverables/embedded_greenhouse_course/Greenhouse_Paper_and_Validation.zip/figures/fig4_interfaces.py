"""Proposed electrical interfaces for course-paper design; not an as-built CAD sheet.
Regenerate with: python3 fig4_interfaces.py
"""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/course-paper-mpl')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/course-paper-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon
from matplotlib import font_manager

out = Path(__file__).resolve().parent
font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
if Path(font_path).exists():
    font_manager.fontManager.addfont(font_path)
plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':10.5,
                     'pdf.fonttype':42, 'axes.linewidth':1.1})
C='#132A3A'; ACC='#146C94'
fig=plt.figure(figsize=(6.1,8.5),facecolor='white')
gs=fig.add_gridspec(3,1,height_ratios=[1,1,1.7],hspace=.25)
axes=[fig.add_subplot(gs[i]) for i in range(3)]
def line(ax,x,y,**kw):
    ax.plot(x,y,color=C,lw=1.35,solid_capstyle='round',**kw)
def text(ax,x,y,s,**kw):
    ax.text(x,y,s,color=C,fontsize=kw.pop('fontsize',10.5),**kw)
def node(ax,x,y):
    ax.add_patch(Circle((x,y),.075,color=C))
def ground(ax,x,y):
    line(ax,[x,x],[y+.25,y])
    for off,w in [(0,.40),(-.13,.28),(-.26,.12)]:line(ax,[x-w,x+w],[y+off,y+off])
def rh(ax,x1,x2,y,label):
    xx=[x1,x1+.15];yy=[y,y]
    for i in range(8):xx.append(x1+.15+(x2-x1-.3)*(i+.5)/8);yy.append(y+(.14 if i%2==0 else -.14))
    xx.extend([x2-.15,x2]);yy.extend([y,y])
    line(ax,xx,yy);text(ax,(x1+x2)/2,y+.38,label,ha='center')
def rv(ax,x,y1,y2,label,ldr=False):
    xx=[x,x];yy=[y1,y1-.10]
    for i in range(8):yy.append(y1-.10-(y1-y2-.2)*(i+.5)/8);xx.append(x+(.13 if i%2==0 else -.13))
    xx.extend([x,x]);yy.extend([y2+.1,y2]);line(ax,xx,yy)
    text(ax,x+.40,(y1+y2)/2,label,va='center')
    if ldr:
        for dy in [.1,.5]:
            ax.annotate('',xy=(x-.22,(y1+y2)/2+dy-.25),xytext=(x-.82,(y1+y2)/2+dy+.25),arrowprops={'arrowstyle':'->','color':ACC,'lw':1.2})
for ax in axes:
    ax.axis('off');ax.set_xlim(0,13.8)

ax=axes[0];ax.set_ylim(0,4.5)
text(ax,.1,4.05,'(a) 模拟光照采集',fontweight='bold',fontsize=11.5)
text(ax,.6,3.25,'3.3 V',ha='center')
line(ax,[.6,2],[2.85,2.85]);rh(ax,2,4.2,2.85,'10 kΩ');line(ax,[4.2,9.2],[2.85,2.85]);node(ax,5.2,2.85)
text(ax,9.45,2.85,'PA1 / ADC1_IN1',va='center')
line(ax,[5.2,5.2],[2.85,2.4]);rv(ax,5.2,2.4,1.35,'光敏电阻',ldr=True);line(ax,[5.2,5.2],[1.35,.85]);ground(ax,5.2,.60)
text(ax,8.0,1.35,'光越强 → 电阻越小\nADC 电压越低',va='center',fontsize=10)

ax=axes[1];ax.set_ylim(0,4.5)
text(ax,.1,4.05,'(b) 超声回波电平缩放',fontweight='bold',fontsize=11.5)
text(ax,.4,3.25,'HC-SR04 ECHO\n标称 5 V',ha='left',fontsize=9.8)
line(ax,[.5,2.8],[2.65,2.65]);rh(ax,2.8,4.8,2.65,'12 kΩ');line(ax,[4.8,9.2],[2.65,2.65]);node(ax,5.8,2.65)
text(ax,9.45,2.65,'PB5 / EXTI5',va='center')
line(ax,[5.8,5.8],[2.65,2.25]);rv(ax,5.8,2.25,1.15,'18 kΩ');line(ax,[5.8,5.8],[1.15,.8]);ground(ax,5.8,.55)
text(ax,8.15,1.25,'5.0 V → 3.0 V\n分压地与 MCU 共地',va='center',fontsize=10)

ax=axes[2];ax.set_ylim(0,7.6)
text(ax,.1,7.20,'(c) 低压风扇的低侧开关驱动',fontweight='bold',fontsize=11.5)
# Main power path: 5 V -> motor -> NMOS -> common ground.
text(ax,8.2,6.7,'+5 V',ha='center')
line(ax,[8.2,8.2],[6.4,5.85]);node(ax,8.2,6.2)
ax.add_patch(Circle((8.2,5.25),.60,fill=False,edgecolor=C,lw=1.4))
text(ax,8.2,5.25,'M',ha='center',va='center',fontsize=13)
text(ax,7.25,5.20,'风扇',ha='right',va='center')
line(ax,[8.2,8.2],[4.65,3.65]);node(ax,8.2,4.25)
# N-channel enhancement MOSFET: separated insulated gate and dashed channel.
line(ax,[6.15,6.15],[2.0,3.75])
for lo,hi in [(2.05,2.45),(2.65,3.05),(3.25,3.65)]:line(ax,[6.7,6.7],[lo,hi])
line(ax,[6.7,8.2],[3.65,3.65]);line(ax,[6.7,8.2],[2.05,2.05])
line(ax,[8.2,8.2],[2.05,.80]);node(ax,8.2,2.05)
# Body connection to source, arrow points into N-channel.
line(ax,[7.5,7.5],[2.05,2.85])
ax.annotate('',xy=(6.72,2.85),xytext=(7.5,2.85),arrowprops={'arrowstyle':'-|>','color':C,'lw':1.1,'mutation_scale':10})
text(ax,8.55,3.55,'D',fontsize=9);text(ax,8.55,2.0,'S',fontsize=9)
text(ax,6.0,3.95,'Q1',ha='center')
text(ax,9.0,2.9,'N 沟道 MOSFET\n须在 VGS=3.3 V 下\n有足够导通能力',va='center',fontsize=9.8)
# Gate drive, gate resistor and pulldown.
text(ax,.4,3.2,'PB0\nTIM3_CH3',va='bottom',fontsize=10)
line(ax,[.5,2.0],[2.85,2.85]);rh(ax,2.0,3.8,2.85,'100 Ω');line(ax,[3.8,6.15],[2.85,2.85]);node(ax,4.5,2.85)
text(ax,5.9,3.0,'G',ha='right',fontsize=9)
line(ax,[4.5,4.5],[2.85,2.35]);rv(ax,4.5,2.35,1.35,'100 kΩ');line(ax,[4.5,4.5],[1.35,.8])
# Common ground rail.
line(ax,[3.7,8.2],[.8,.8]);ground(ax,6.6,.55)
text(ax,1.4,.7,'MCU GND',ha='center');line(ax,[2.8,3.7],[.8,.8])
# Flyback diode connected antiparallel across motor: cathode to 5 V.
line(ax,[8.2,11.1,11.1],[6.2,6.2,5.7]);line(ax,[8.2,11.1,11.1],[4.25,4.25,4.9])
ax.add_patch(Polygon([(10.72,4.92),(11.48,4.92),(11.1,5.55)],closed=True,facecolor='white',edgecolor=C,lw=1.35))
line(ax,[10.65,11.55],[5.65,5.65]);line(ax,[11.1,11.1],[5.55,5.7])
text(ax,11.75,5.3,'D1\n阴极接 +5 V',va='center',fontsize=9.7)
text(ax,.3,-.02,'示意连接；上电前核对模块额定值，负载供电、去耦及驱动须按实物选型。',fontsize=8.5)
fig.subplots_adjust(left=.035,right=.985,top=.985,bottom=.03)
fig.savefig(out/'fig4_interfaces.pdf',bbox_inches='tight',pad_inches=.08)
fig.savefig(out/'fig4_interfaces.png',dpi=300,bbox_inches='tight',pad_inches=.08)
plt.close(fig)
