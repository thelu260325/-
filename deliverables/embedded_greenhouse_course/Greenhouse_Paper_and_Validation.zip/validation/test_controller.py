import math
import unittest
from controller import Controller, light_index


class ControlTests(unittest.TestCase):
    def fresh(self, temperature=23, adc=2457, now=0):
        c = Controller()
        c.update_temperature(temperature, now)
        c.update_humidity(55, now)
        c.update_pressure(1013, now)
        c.update_light(adc, now)
        return c

    def test_adc_mapping_is_inverse_and_relative(self):
        self.assertEqual(light_index(4095), 0)
        self.assertEqual(light_index(0), 100)
        self.assertAlmostEqual(light_index(2048), 49.9877899878)

    def test_bad_adc_rejected(self):
        for value in [-1, 4096, 2.5, None, True]:
            with self.assertRaises(ValueError): light_index(value)

    def test_cold_requests_heat(self):
        out = self.fresh(17).tick(0)
        self.assertTrue(out.heat)
        self.assertEqual(out.fan_percent, 0)

    def test_heat_lower_boundary_and_hysteresis(self):
        c = self.fresh(18)
        self.assertFalse(c.tick(0).heat)
        c.update_temperature(17.9, 1)
        self.assertTrue(c.tick(1).heat)
        c.update_temperature(19.9, 2)
        self.assertTrue(c.tick(2).heat)
        c.update_temperature(20, 3)
        self.assertFalse(c.tick(3).heat)

    def test_fan_upper_boundary_and_hysteresis(self):
        c = self.fresh(27.9)
        self.assertEqual(c.tick(0).fan_percent, 0)
        c.update_temperature(28, 1)
        self.assertEqual(c.tick(1).fan_percent, 70)
        c.update_temperature(26.1, 2)
        self.assertEqual(c.tick(2).fan_percent, 70)
        c.update_temperature(26, 3)
        self.assertEqual(c.tick(3).fan_percent, 0)

    def test_light_hysteresis(self):
        c = self.fresh(adc=3276)  # index 20
        self.assertTrue(c.tick(0).light)
        c.update_light(2457, 1)  # index 40, retain on
        self.assertTrue(c.tick(1).light)
        c.update_light(0, 2)  # index 100
        self.assertFalse(c.tick(2).light)
        c.update_light(2457, 3)
        self.assertFalse(c.tick(3).light)

    def test_temperature_missing_default_is_safe(self):
        out = Controller().tick(0)
        self.assertFalse(out.heat)
        self.assertEqual(out.fan_percent, 40)
        self.assertIn('TEMP', out.faults)

    def test_temperature_freshness_boundary(self):
        c = self.fresh(17)
        self.assertTrue(c.tick(3).heat)
        out = c.tick(3.001)
        self.assertFalse(out.heat)
        self.assertEqual(out.fan_percent, 40)

    def test_nonfinite_temp_invalidates_only_temperature(self):
        c = self.fresh(17)
        c.update_temperature(float('nan'), 0)
        out = c.tick(0)
        self.assertEqual(out.faults, ('TEMP',))
        self.assertFalse(out.heat)

    def test_temperature_recovers_from_fault(self):
        c = Controller()
        c.tick(0)
        c.update_temperature(17, 1)
        self.assertTrue(c.tick(1).heat)

    def test_humidity_stale_is_not_fake_zero(self):
        c = self.fresh()
        self.assertEqual(c.displayed(6)['humidity_percent'], 55)
        self.assertIsNone(c.displayed(6.001)['humidity_percent'])
        self.assertIn('HUMIDITY', c.tick(6.001).faults)

    def test_bad_humidity_does_not_disable_temperature_control(self):
        c = self.fresh(17)
        c.update_humidity(101, 0)
        out = c.tick(0)
        self.assertTrue(out.heat)
        self.assertEqual(out.faults, ('HUMIDITY',))

    def test_manual_command_and_expiry(self):
        c = self.fresh(23)
        c.set_manual(0, light=True, fan=25)
        self.assertEqual(c.tick(0).fan_percent, 25)
        self.assertEqual(c.tick(29.9).mode, 'MANUAL')
        c.update_temperature(23, 30)
        c.update_light(0, 30)
        out = c.tick(30)
        self.assertEqual(out.mode, 'AUTO')
        self.assertEqual(out.fan_percent, 0)
        self.assertFalse(out.light)

    def test_manual_heat_and_cooling_interlocked(self):
        c = self.fresh(23)
        c.set_manual(0, heat=True, fan=90)
        out = c.tick(0)
        self.assertTrue(out.heat)
        self.assertEqual(out.fan_percent, 0)

    def test_high_temperature_overrides_manual_heat(self):
        c = self.fresh(35)
        c.set_manual(0, heat=True, fan=0)
        out = c.tick(0)
        self.assertFalse(out.heat)
        self.assertEqual(out.fan_percent, 100)

    def test_temperature_fault_overrides_manual_heat(self):
        c = self.fresh()
        c.set_manual(0, heat=True, fan=0)
        c.update_temperature(None, 0)
        out = c.tick(0)
        self.assertFalse(out.heat)
        self.assertEqual(out.fan_percent, 40)

    def test_light_fault_overrides_manual_light(self):
        c = self.fresh()
        c.set_manual(0, light=True)
        c.update_light(None, 0)
        self.assertFalse(c.tick(0).light)

    def test_distance_requires_three_consecutive_near_samples(self):
        c = self.fresh(); c.armed = True
        for cm in [40, 40]: c.update_distance(cm)
        self.assertFalse(c.alarm)
        c.update_distance(40)
        self.assertTrue(c.alarm)

    def test_distance_invalid_resets_debounce(self):
        c = self.fresh(); c.armed = True
        for cm in [40, 40, None, 40, 40]: c.update_distance(cm)
        self.assertFalse(c.alarm)
        c.update_distance(40)
        self.assertTrue(c.alarm)

    def test_distance_middle_band_resets_debounce(self):
        c = self.fresh(); c.armed = True
        for cm in [40, 40, 50, 40, 40, 70]: c.update_distance(cm)
        self.assertFalse(c.alarm)

    def test_unarmed_does_not_trigger_alarm(self):
        c = self.fresh()
        for _ in range(5): c.update_distance(40)
        self.assertFalse(c.alarm)

    def test_alarm_override_and_latch_clear(self):
        c = self.fresh(17); c.armed = True
        c.set_manual(0, heat=True, light=True)
        for _ in range(3): c.update_distance(40)
        out = c.tick(0)
        self.assertEqual((out.heat, out.light, out.fan_percent, out.buzzer), (False, False, 100, True))
        self.assertFalse(c.acknowledge())
        for _ in range(2): c.update_distance(80)
        self.assertFalse(c.acknowledge())
        c.update_distance(80)
        self.assertTrue(c.alarm)  # far condition alone does not unlatch
        self.assertTrue(c.acknowledge())
        self.assertFalse(c.alarm)

    def test_invalid_distance_blocks_alarm_ack(self):
        c = self.fresh(); c.armed = True
        for _ in range(3): c.update_distance(40)
        for _ in range(3): c.update_distance(80)
        c.update_distance(None)
        self.assertFalse(c.acknowledge())

    def test_disarm_does_not_unlatch_alarm(self):
        c = self.fresh(); c.armed = True
        for _ in range(3): c.update_distance(40)
        c.armed = False
        self.assertTrue(c.alarm)

    def test_record_period_and_no_duplicate_same_tick(self):
        c = self.fresh()
        c.tick(59.9); self.assertEqual(len(c.records), 0)
        c.tick(60); c.tick(60)
        self.assertEqual(len(c.records), 1)
        c.tick(120)
        self.assertEqual([r['scheduled_time_s'] for r in c.records], [60, 120])

    def test_record_gap_is_explicit_not_backfilled_with_fake_samples(self):
        c = self.fresh()
        c.tick(130)
        self.assertEqual(len(c.records), 1)
        r = c.records[0]
        self.assertEqual((r['actual_time_s'], r['scheduled_time_s'], r['skipped_intervals']), (130, 120, 1))
        self.assertIsNone(r['sensors']['temperature_C'])
        self.assertEqual(c.next_record, 180)

    def test_time_cannot_go_backwards(self):
        c = self.fresh(); c.tick(1)
        with self.assertRaises(ValueError): c.tick(0.9)

    def test_bad_manual_pwm_rejected(self):
        c = self.fresh()
        for fan in [-1, 101, 50.5, True]:
            with self.assertRaises(ValueError): c.set_manual(0, fan=fan)


if __name__ == '__main__':
    unittest.main(verbosity=2)
