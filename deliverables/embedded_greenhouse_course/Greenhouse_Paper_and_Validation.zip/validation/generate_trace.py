from controller import Controller
from pathlib import Path
import csv
c = Controller()
rows=[]

def step(t, temp, adc, note, action=None):
    c.update_temperature(temp,t); c.update_light(adc,t)
    c.update_humidity(55,t); c.update_pressure(1013,t)
    if action: action()
    o=c.tick(t)
    rows.append({'time_s':t,'input_temperature_C':temp,'input_ADC':adc,
                 'mode':o.mode,'heat':int(o.heat),'light':int(o.light),
                 'fan_percent':o.fan_percent,'buzzer':int(o.buzzer),
                 'faults':'|'.join(o.faults),'scenario_note':note})

step(0,17,3276,'cold and dark: heating and light')
step(1,19,2457,'temperature/light hysteresis holds')
step(2,20,0,'heat and lamp release thresholds passed')
step(3,28,0,'fan starts at 28C')
step(4,27,0,'fan hysteresis retains 70 percent')
step(5,26,0,'fan stops at 26C')
step(6,23,0,'manual heating command',lambda:c.set_manual(6,heat=True,light=True,fan=80))
step(7,35,0,'high temperature overrides manual heat')
step(8,None,0,'invalid temperature overrides manual heat')
step(9,23,0,'temperature recovers, unexpired manual command resumes')
def alarm():
    c.armed=True
    for _ in range(3): c.update_distance(40)
step(10,23,0,'third near sample: latched intrusion alarm',alarm)
def far():
    for _ in range(3): c.update_distance(80)
step(11,23,0,'far condition met but no acknowledgement: alarm stays',far)
step(12,23,0,'acknowledge after clear condition: alarm releases',c.acknowledge)
step(36,23,0,'manual lifetime elapsed: return AUTO')
path=Path(__file__).with_name('scenario_trace.csv')
with path.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(path)
