"""Host-only reference model for a teaching greenhouse controller.

No GPIO, MCU firmware, RTOS scheduling or physical calibration is simulated.
Times are monotonic seconds. Nonfinite/out-of-range values invalidate only
that sensor and cannot be interpreted as zero measurements.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import floor, isfinite
from typing import Optional


@dataclass(frozen=True)
class Sample:
    value: Optional[float]
    time: float

    def fresh(self, now: float, max_age: float) -> bool:
        return self.value is not None and 0 <= now - self.time <= max_age


@dataclass(frozen=True)
class Outputs:
    heat: bool
    light: bool
    fan_percent: int
    buzzer: bool
    mode: str
    faults: tuple[str, ...]


def light_index(adc: int) -> float:
    """0=dark, 100=bright for fixed pullup to 3.3 V, LDR to ground.

    ADC voltage increases when the LDR dark resistance increases, hence inverse.
    This relative index is not illuminance in lux.
    """
    if isinstance(adc, bool) or not isinstance(adc, int) or not 0 <= adc <= 4095:
        raise ValueError("ADC code must be a 12-bit integer")
    return 100.0 * (4095 - adc) / 4095


class Controller:
    TEMP_AGE = 3.0
    HUMIDITY_AGE = 6.0
    PRESSURE_AGE = 6.0
    LIGHT_AGE = 2.0
    MANUAL_LIFETIME = 30.0

    def __init__(self):
        self.temperature = Sample(None, 0)
        self.humidity = Sample(None, 0)
        self.pressure = Sample(None, 0)
        self.light = Sample(None, 0)
        self.mode = "AUTO"
        self.manual_until = 0.0
        self.manual_heat = False
        self.manual_light = False
        self.manual_fan = 0
        self.auto_heat = False
        self.auto_light = False
        self.auto_fan = 0
        self.armed = False
        self.alarm = False
        self.near_count = 0
        self.far_count = 0
        self.intrusion_clear = False
        self.last_tick = 0.0
        self.next_record = 60.0
        self.records = []

    @staticmethod
    def _sample(value, now, lo, hi):
        valid = value is not None and isinstance(value, (int, float)) and isfinite(value) and lo <= value <= hi
        return Sample(float(value) if valid else None, now)

    def update_temperature(self, value, now):
        # DS18B20 digital output range; this is not an accuracy assertion.
        self.temperature = self._sample(value, now, -55, 125)

    def update_humidity(self, value, now):
        # Physical %RH domain, no unverified DHT11 accuracy claim.
        self.humidity = self._sample(value, now, 0, 100)

    def update_pressure(self, value, now):
        self.pressure = self._sample(value, now, 300, 1100)

    def update_light(self, adc, now):
        try:
            self.light = Sample(light_index(adc), now)
        except ValueError:
            self.light = Sample(None, now)

    def update_distance(self, cm):
        valid = cm is not None and isinstance(cm, (int, float)) and isfinite(cm) and 2 <= cm <= 400
        if not valid:
            self.near_count = self.far_count = 0
            self.intrusion_clear = False
            return
        if cm < 50:
            self.near_count = min(self.near_count + 1, 3)
            self.far_count = 0
            self.intrusion_clear = False
            if self.armed and self.near_count >= 3:
                self.alarm = True
        elif cm > 70:
            self.far_count = min(self.far_count + 1, 3)
            self.near_count = 0
            self.intrusion_clear = self.far_count >= 3
        else:
            self.near_count = self.far_count = 0
            self.intrusion_clear = False

    def acknowledge(self):
        if self.alarm and self.intrusion_clear:
            self.alarm = False
            return True
        return False

    def set_manual(self, now, *, heat=False, light=False, fan=0):
        if not isinstance(fan, int) or isinstance(fan, bool) or not 0 <= fan <= 100:
            raise ValueError("fan duty must be an integer in [0,100]")
        self.mode = "MANUAL"
        self.manual_until = now + self.MANUAL_LIFETIME
        self.manual_heat, self.manual_light, self.manual_fan = bool(heat), bool(light), fan

    def set_auto(self):
        self.mode = "AUTO"

    def displayed(self, now):
        return {
            "temperature_C": self.temperature.value if self.temperature.fresh(now, self.TEMP_AGE) else None,
            "humidity_percent": self.humidity.value if self.humidity.fresh(now, self.HUMIDITY_AGE) else None,
            "pressure_hPa": self.pressure.value if self.pressure.fresh(now, self.PRESSURE_AGE) else None,
            "relative_light_index": self.light.value if self.light.fresh(now, self.LIGHT_AGE) else None,
        }

    def tick(self, now):
        if not isfinite(now) or now < self.last_tick:
            raise ValueError("ticks must use finite monotonic times")
        self.last_tick = now
        temp_ok = self.temperature.fresh(now, self.TEMP_AGE)
        light_ok = self.light.fresh(now, self.LIGHT_AGE)
        faults = []
        for label, sample, age in [
            ("TEMP", self.temperature, self.TEMP_AGE),
            ("HUMIDITY", self.humidity, self.HUMIDITY_AGE),
            ("PRESSURE", self.pressure, self.PRESSURE_AGE),
            ("LIGHT", self.light, self.LIGHT_AGE),
        ]:
            if not sample.fresh(now, age):
                faults.append(label)
        if temp_ok:
            temp = self.temperature.value
            if temp < 18:
                self.auto_heat = True
            elif temp >= 20:
                self.auto_heat = False
            if temp >= 28:
                self.auto_fan = 70
            elif temp <= 26:
                self.auto_fan = 0
        else:
            self.auto_heat = False
            self.auto_fan = 40
        if light_ok:
            if self.light.value < 30:
                self.auto_light = True
            elif self.light.value >= 45:
                self.auto_light = False
        else:
            self.auto_light = False
        if self.mode == "MANUAL" and now >= self.manual_until:
            self.mode = "AUTO"
        if self.mode == "MANUAL":
            heat, light, fan = self.manual_heat, self.manual_light, self.manual_fan
        else:
            heat, light, fan = self.auto_heat, self.auto_light, self.auto_fan
        # Protection order: ordinary command -> sensor failure -> high temp -> alarm.
        if not temp_ok:
            heat, fan = False, 40
        if not light_ok:
            light = False
        if temp_ok and self.temperature.value >= 35:
            heat, fan = False, 100
        if self.alarm:
            heat, light, fan = False, False, 100
        # No simultaneous heating and ordinary cooling, even in manual mode.
        if heat:
            fan = 0
        output = Outputs(heat, light, fan, self.alarm, self.mode, tuple(faults))
        if now >= self.next_record:
            skipped = floor((now - self.next_record) / 60)
            scheduled = self.next_record + skipped * 60
            self.records.append({"actual_time_s": now, "scheduled_time_s": scheduled,
                                 "skipped_intervals": skipped, "sensors": self.displayed(now),
                                 "outputs": output.__dict__.copy()})
            self.next_record = scheduled + 60
        return output
