"""Run current tests and write evidence without swallowing test failures."""
from pathlib import Path
import unittest, io, json, sys, platform
from datetime import datetime, timezone
base = Path(__file__).resolve().parent
suite = unittest.defaultTestLoader.discover(str(base), pattern='test_controller.py')
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
output = stream.getvalue()
(base/'test_result.txt').write_text(output, encoding='utf-8')
summary = {'scope':'Host-side Python behavioral model only; no physical hardware, STM32 compilation or FreeRTOS timing verification',
           'utc_time':datetime.now(timezone.utc).isoformat(), 'python':platform.python_version(),
           'tests_run':result.testsRun, 'failures':len(result.failures), 'errors':len(result.errors),
           'skipped':len(result.skipped), 'success':result.wasSuccessful()}
(base/'test_result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(output, end='')
sys.exit(0 if result.wasSuccessful() else 1)
