
August 26, 2015


IEEEtran is a LaTeX class for authors of the Institute of Electrical and
Electronics Engineers (IEEE) transactions journals and conferences.
The latest version of the IEEEtran package can be found at CTAN:

http://www.ctan.org/pkg/ieeetran

as well as within IEEE's site:

http://www.ieee.org/

For latest news, helpful tips, answers to frequently asked questions,
beta releases and other support, visit the IEEEtran home page at my
website:

http://www.michaelshell.org/tex/ieeetran/

Version 1.8b has a number of significant changes over the v1.8a release.
For a full history of changes, please read the file changelog.txt.
The most notable changes in this release include:

 1) Added new comsoc mode for the IEEE Communications Society.
    This mode (at present) only invokes the use of the newtxmath math fonts.
 
 2) Revised IEEEeqnarray column specifications to work with active " 
    (or other punctuation catcode changes) as with babel under the
    german or ngerman language modes. 
    Thanks to Stefan M. Moser for reporting this problem.

 3) Added \indexspace and other index related macros as newer versions of
    article.cls now do. These macros are needed to avoid an error when
    using the glossaries package.
    Thanks to Sebastian Nyberg for suggesting this change.

 4) Fixed odd/even page header font bug under compsoc mode and
    other page style code improvements.
    Thanks to Marco Paolieri for reporting this problem.

 5) Added hooks to allow for easy control of spacing above title.

 6) Added the \IEEEnoauxwrite command.
    Thanks to Sudarshan Mukherjee for suggesting this feature.


NOTE: Take care not to confuse the "comsoc" and "compsoc" class
options/modes as they are very different:

comsoc  ==> IEEE Communications Society
compsoc ==> IEEE Computer Society

The comsoc mode requires that an acceptable Times math font be available on
the LaTeX system. This requirement will be enforced by IEEEtran in comsoc
mode. Either the freely available newtxmath font by Michael Sharpe
http://www.ctan.org/pkg/newtx
(version 1.451, July 28, 2015 or later is recommended)
or the commercial MathTime font (e.g., mtpro2.sty) is acceptable.
See Section II-D (2.4) "Class Options - comsoc, compsoc, transmag" of
the IEEEtran HOWTO for more details.


Best wishes for all your publication endeavors,

Michael Shell
http://www.michaelshell.org/


***************************** Subdirectories ******************************

bibtex   - The IEEEtran BibTeX style package.

extras   - Supplementary material that may be of interest.

testflow - The testflow diagnostic suite for verifying PS/PDF output.

tools    - The IEEEtrantools.sty package which provides several commands
           from the IEEEtran.cls file for use with other LaTeX classes.


********************************** Files **********************************

README                 - This file.

IEEEtran.cls           - The IEEEtran LaTeX class file.

changelog.txt          - The revision history.

IEEEtran_HOWTO.pdf     - The IEEEtran LaTeX class user manual.

bare_conf.tex          - A bare bones starter file for IEEE conference papers.

bare_conf_compsoc.tex  - A bare bones starter file for IEEE Computer Society
                         conference papers.

bare_jrnl.tex          - A bare bones starter file for IEEE journal papers.

bare_jrnl_comsoc.tex   - A bare bones starter file for IEEE Communications
                         Society journal papers.

bare_jrnl_compsoc.tex  - A bare bones starter file for IEEE Computer Society
                         journal papers.

bare_jrnl_transmag.tex - A bare bones starter file for IEEE Transactions
                         on Magnetics journal papers.

bare_adv.tex           - A bare bones starter file showing advanced
                         techniques such as conditional compilation,
                         hyperlinks, PDF thumbnails, etc. The illustrated
                         format is for an IEEE Computer Society journal paper.

***************************************************************************
Legal Notice:
This code is offered as-is without any warranty either expressed or
implied; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE! 
User assumes all risk.
In no event shall the IEEE or any contributor to this code be liable for
any damages or losses, including, but not limited to, incidental,
consequential, or any other damages, resulting from the use or misuse
of any information contained here.

All comments are the opinions of their respective authors and are not
necessarily endorsed by the IEEE.

This work is distributed under the LaTeX Project Public License (LPPL)
( http://www.latex-project.org/ ) version 1.3, and may be freely used,
distributed and modified. A copy of the LPPL, version 1.3, is included
in the base LaTeX documentation of all distributions of LaTeX released
2003/12/01 or later.
Retain all contribution notices and credits.
** Modified files should be clearly indicated as such, including  **
** renaming them and changing author support contact information. **

File list of work: IEEEtran.cls, IEEEtran_HOWTO.pdf, bare_adv.tex,
                   bare_conf.tex, bare_conf_compsoc.tex,
                   bare_jrnl.tex, bare_jrnl_comsoc.tex,
                   bare_jrnl_compsoc.tex, bare_jrnl_transmag.tex
***************************************************************************
